#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <signal.h>

struct PRODUCT
{
	char *name;
	int price;
	PRODUCT *fd;
	PRODUCT *bk;
}

int __cdecl my_read(void *buf, size_t nbytes)
{
	int result; // eax
	ssize_t v3; // [esp+1Ch] [ebp-Ch]

	v3 = read(0, buf, nbytes);
	if (v3 == -1)
		return puts("Input Error.");
	result = (int)buf + v3;
	*((_BYTE *)buf + v3) = 0;
	return result;
}

void menu(void)
{
	puts("=== Menu ===");
	printf("%d: Apple Store\n", 1);
	printf("%d: Add into your shopping cart\n", 2);
	printf("%d: Remove from your shopping cart\n", 3);
	printf("%d: List your shopping cart\n", 4);
	printf("%d: Checkout\n", 5);
	printf("%d: Exit\n", 6);
	return;
}

void list(void)
{
	puts("=== Device List ===");
	printf("%d: iPhone 6 - $%d\n", 1, 199);
	printf("%d: iPhone 6 Plus - $%d\n", 2, 299);
	printf("%d: iPad Air 2 - $%d\n", 3, 499);
	printf("%d: iPad Mini 3 - $%d\n", 4, 399);
	printf("%d: iPod Touch - $%d\n", 5, 199);
	return;
}

PRODUCT *create(char *name, int price)
{
	PRODUCT *product;

	product = (PRODUCT *)malloc(0x10);
	product->price = price;
	asprintf((char **)product, "%s", name);
	product->fd = (PRODUCT *)0x0;
	product->bk = (PRODUCT *)0x0;
	return product;
}

void insert(PRODUCT *product)
{
	PRODUCT *myCART;
	myCART = (PRODUCT *)myCart;
	while (myCART->fd != (PRODUCT *)0x0)
	{
		myCART = myCART->fd;
	}
	myCART->fd = product;
	product->bk = myCART;
	return;
}

void delete (void)

{
	int choice;
	int in_GS_OFFSET;
	int i;
	PRODUCT *P;
	char choose[22];
	int canary;
	PRODUCT *FD;
	PRODUCT *BK;

	canary = *(int *)(in_GS_OFFSET + 0x14);
	i = 1;
	P = myCart._8_4_;
	printf("Item Number> ");
	fflush(stdout);
	my_read(choose, 0x15);
	choice = atoi(choose);
	do
	{
		if (P == (PRODUCT *)0x0)
		{
		LAB_08048a5e:
			if (canary != *(int *)(in_GS_OFFSET + 0x14))
			{
				/* WARNING: Subroutine does not return */
				__stack_chk_fail();
			}
			return;
		}
		if (i == choice)
		{
			FD = P->fd;
			BK = P->bk;
			if (BK != (PRODUCT *)0x0)
			{
				BK->fd = FD;
			}
			if (FD != (PRODUCT *)0x0)
			{
				FD->bk = BK;
			}
			printf("Remove %d:%s from your shopping cart.\n", i, P->name);
			goto LAB_08048a5e;
		}
		i = i + 1;
		P = P->fd;
	} while (true);
}

int cart(void)

{
	int iVar1;
	int in_GS_OFFSET;
	int i;
	int total;
	PRODUCT *product;
	char choice[22];
	int canary;

	iVar1 = *(int *)(in_GS_OFFSET + 0x14);
	i = 1;
	total = 0;
	printf("Let me check your cart. ok? (y/n) > ");
	fflush(stdout);
	my_read(choice, 0x15);
	if (choice[0] == 'y')
	{
		puts("==== Cart ====");
		for (product = myCart._8_4_; product != (PRODUCT *)0x0;
			 product = product->fd)
		{
			printf("%d: %s - $%d\n", i, product->name, product->price);
			total = total + product->price;
			i = i + 1;
		}
	}
	if (iVar1 != *(int *)(in_GS_OFFSET + 0x14))
	{
		/* WARNING: Subroutine does not return */
		__stack_chk_fail();
	}
	return total;
}

void checkout(void)

{
	int in_GS_OFFSET;
	int total;
	PRODUCT product;
	int canary;

	canary = *(int *)(in_GS_OFFSET + 0x14);
	total = cart();
	if (total == 0x1c06)
	{
		puts("*: iPhone 8 - $1");
		asprintf((char **)&product, "%s", "iPhone 8");
		product.price = 1;
		insert(&product);
		total = 0x1c07;
	}
	printf("Total: $%d\n", total);
	puts("Want to checkout? Maybe next time!");
	if (canary != *(int *)(in_GS_OFFSET + 0x14))
	{
		/* WARNING: Subroutine does not return */
		__stack_chk_fail();
	}
	return;
}

void add(void)
{
	int iVarl;
	int choice;
	int in_GS_OFFSET;
	PRODUCT *product;
	char choose[22]; // [esp+26h] [ebp-22h] BYREF

	unsigned int v3; // [esp+3Ch] [ebp-Ch]
	v3 = __readgsdword(0x14u);

	printf("Device Number> ");
	fflush(stdout);
	my_read(choose, 0x15u);
	switch (atoi(choose))
	{
	case 1:
		product = (PRODUCT *)create("iPhone 6", 199);
		insert(product);
		goto LABEL_8;
	case 2:
		product = (PRODUCT *)create("iPhone 6 Plus", 299);
		insert(product);
		goto LABEL_8;
	case 3:
		product = (PRODUCT *)create("iPad Air 2", 499);
		insert(product);
		goto LABEL_8;
	case 4:
		product = (PRODUCT *)create("iPad Mini 3", 399);
		insert(product);
		goto LABEL_8;
	case 5:
		product = (PRODUCT *)create("iPod Touch", 199);
		insert(product);
	LABEL_8:
		printf("You've put %s in your shopping cart.\n", *product);
		puts("Brilliant! That's an amazing idea.");
		break;
	default:
		puts("Stop doing that. Idiot!");
		break;
	}
	return __readgsdword(0x14u) ^ v3;
}

unsigned int handler()
{
	char choose[22]; // [esp+16h] [ebp-22h] BYREF

	// canary
	unsigned int v2; // [esp+2Ch] [ebp-Ch]
	v2 = __readgsdword(0x14u);

	while (1)
	{
		printf("> ");
		fflush(stdout);
		my_read(choose, 0x15u);
		switch (atoi(choose))
		{
		case 1:
			list();
			break;
		case 2:
			add();
			break;
		case 3:
			delete ();
			break;
		case 4:
			cart();
			break;
		case 5:
			checkout();
			break;
		case 6:
			puts("Thank You for Your Purchase!");
			return __readgsdword(0x14u) ^ v2; // check canary
		default:
			puts("It's not a choice! Idiot."); // no choice => break
			break;
		}
	}
}

void main(void)
{
	signal(0xe, timeout);
	alarm(0x3c);
	memset(myCart, 0, 0x10);
	menu();
	handler();
	return;
}



