#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct BULLET
{
	char name[0x30];
	int power;
};

struct WOREWOLF
{
	int power;
	char *name;
};

void init_proc(void)

{
	setvbuf(stdout, (char *)0x0, 2, 0);
	setvbuf(stdin, (char *)0x0, 2, 0);
	return;
}

void menu(void)

{
	puts("+++++++++++++++++++++++++++");
	puts("       Silver Bullet       ");
	puts("+++++++++++++++++++++++++++");
	puts(" 1. Create a Silver Bullet ");
	puts(" 2. Power up Silver Bullet ");
	puts(" 3. Beat the Werewolf      ");
	puts(" 4. Return                 ");
	puts("+++++++++++++++++++++++++++");
	printf("Your choice :");
	return;
}

int read_int(void) // read ascii to int
{
	int choice;
	char local_1c[20];
	ssize_t bullet.power;

	bullet.power = read(0, local_1c, 0xf);
	if (bullet.power < 1)
	{
		puts("read error");
		/* WARNING: Subroutine does not return */
		exit(1);
	}
	choice = atoi(local_1c);
	return choice;
}


/*
Hàm strcat được sử dụng để nối chuỗi nguồn 
vào đuôi của chuỗi đích.

dest -- Đây là con trỏ tới mảng đích, 
mà: nên chứa một chuỗi và nên đủ lớn để chứa chuỗi kết quả 
sau khi đã được nối chuỗi. 

src -- Đây là chuỗi để được phụ thêm (append) vào cuối. 
Hàm này trả về một con trỏ tới chuỗi kết quả dest.
*/
void power_up(BULLET *bullet)
// bug off-by-one => overwrite bullet->power is length bullet->name => could overwrite return eip saved
{
	size_t len;
	int powerup;
	char name[48];
	int power;

	bullet.power = 0;
	memset(name, 0, 0x30);
	if (bullet->name[0] == 0)
	{
		puts("You need create the bullet first !");
	}
	else if ((uint)bullet->power < 0x30)
	{
		printf("Give me your another description of bullet :");
		read_input(name, 0x30 - bullet->power);
		strncat((char *)bullet, name, 0x30 - bullet->power);
		len = strlen(name);
		powerup = bullet->power + len;
		printf("Your new power is : %u\n", powerup);
		bullet->power = powerup;
		puts("Enjoy it !");
	}
	else
	{
		puts("You can\'t power up any more !");
	}
	return;
}

void create_bullet(BULLET *bullet)

{
	size_t power;

	if (bullet->name[0] == 0)
	{
		printf("Give me your description of bullet :", 0);
		read_input(bullet, 0x30);
		power = strlen((char *)bullet);
		printf("Your power is : %u\n", power);
		bullet->power = power;
		puts("Good luck !!");
	}
	else
	{
		puts("You have been created the Bullet !");
	}
	return;
}

undefined4 beat(BULLET *bullet, WOREWOLF *werewolf)

{
	undefined4 uVar1;

	if (bullet->name[0] == 0)
	{
		puts("You need create the bullet first !");
		uVar1 = 0;
	}
	else
	{
		puts(">----------- Werewolf -----------<");
		printf(" + NAME : %s\n", werewolf->name);
		printf(" + HP : %d\n", werewolf->power);
		puts(">--------------------------------<");
		puts("Try to beat it .....");
		usleep(1000000);
		werewolf->power = werewolf->power - bullet->power;
		if (werewolf->power < 1)
		{
			puts("Oh ! You win !!");
			uVar1 = 1;
		}
		else
		{
			puts("Sorry ... It still alive !!");
			uVar1 = 0;
		}
	}
	return uVar1;
}

undefined4 main(void)

{
	int choice;
	WOREWOLF werewolf;
	BULLET bullet;

	init_proc();
	bullet.power = 0;
	memset(&bullet, 0, 0x30);
	werewolf.power = 0x7fffffff;
	werewolf.name = (int)&GIN;	// global variable : "GIN"
	do
	{
		while (true)
		{
			while (true)
			{
				menu();
				choice = read_int();
				if (choice != 2)
					break;
				power_up(&bullet);
			}
			if (2 < choice)
				break;
			if (choice == 1)
			{
				create_bullet(&bullet);
			}
			else
			{
			LAB_08048a05:
				puts("Invalid choice");
			}
		}
		if (choice != 3)
		{
			if (choice == 4)
			{
				puts("Don\'t give up !");
				/* WARNING: Subroutine does not return */
				exit(0);
			}
			goto LAB_08048a05;
		}
		choice = beat(&bullet, &werewolf.power); // # error
		if (choice != 0)
		{
			return 0;
		}
		puts("Give me more power !!");
	} while (true);
}


