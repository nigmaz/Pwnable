# [pwnable.tw] - Silver Bullet

<img src="./images/Silver Bullet.png" alt="Silver Bullet" width="500" height="300">

## A. CHALLENGE 

### [1] Binary Mitigations. 

- Bài cho file thực thi và thư viện => pwninit patch thư viện vào file, kiểm tra thông tin cơ bản của file.

![checksec.png](./images/checksec.png)

> Chương trình 32-bit tên các hàm bị xóa, có CANARY và NX là được bật. Kiểm tra version của libc được cung cấp là 2.23 .

## B. OVERVIEW

![run.png](./images/run.png)



### [1] Vulnerability Analysis.



#### [+] BUG.



### [2] Idea Exploit.


## C. EXPLOITATION


## D. FLAG

- Tiến hành viết file [exp.py](./exp.py) và khai thác:

![flag.png](./images/flag.png)
